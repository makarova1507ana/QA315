# from polygon import perimeter
# print(perimeter(4,5,6))

# from polygon import *
# print(valid_polygon(4,5,6))
# print(perimeter(4,5,6))

import polygon # подключаем пространство
print(polygon.valid_polygon(4,5,6))
